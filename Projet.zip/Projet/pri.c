#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "process.h"
#include "Affichage.h"



 void PRI (Info tab[],int m) {

printf("\n");
char ch2[50];
float s=0;
	float rt=0;
 int r =0 ;
 char ch1[20];
Info aux ;
	Info tab2[50];
	Info tab3[50];
 for(int h=0 ; h<m;h++){
tab2[h]=tab[h];
}
for(int o=0 ; o<m-1;o++){
for(int h = o+1 ; h <m ; h++){
	if(tab2[o].pr<tab2[h].pr){
	aux=tab2[h];
	tab2[h]=tab2[o];
	tab2[o]=aux;}
}
}

for(int h=0 ; h<m;h++){
tab3[h]=tab[h];
}
for(int o=0 ; o<m-1;o++){
for(int h = o+1 ; h <m ; h++){
	if(tab3[o].ta>tab3[h].ta){
	aux=tab3[h];
	tab3[h]=tab3[o];
	tab3[o]=aux;}
}
}

strncpy(ch1, "", sizeof(ch1));
int h = 0; 
int p=0 ;
ch2[0]=0;
int time=0;
while(p!=m){
while(tab2[h].te !=0){

if(tab2[h].ta <=time){
	s+=time-tab2[h].ta;
time+=tab2[h].te;
rt+=time-tab2[h].ta;
tab2[h].te=0;
 ch1[r]=tab2[h].num;
 ch2[r+1]=time;

h=0;
	p=0;
	r++;
}

else {
	
	
	int nb=0;
	for(int f = 0 ; f <m ; f++){
	if((tab2[f].ta<=time) && (tab2[f].te>0)){
	nb++;
}}
if(nb==0){
	for(int f = 0 ; f <m ; f++){
	if(tab3[f].ta>time){
		time=tab3[f].ta;
		ch1[r]=0;
ch2[r+1]=time;
r++;
h=0;
p=0;
break;
	}
	
}

}
	
	else{
	
	h++;
if(h==m)
h=0;}
}

}
h++;
if(h==m)
h=0;

p++;

}

Affichage_dessus("Non Preemptive Priority ",r);

 for(int h = 0 ; h<r; h++){
 if(ch1[h]==0)
 	printf("   X ");
 	else
	printf("   p %d ",ch1[h]  );
	printf("\t");
	}
	printf("\n");
	printf("\n");
	printf("\t");
	 for(int h = 0 ; h<=r; h++){
	printf("%d ",ch2[h] );
	printf("\t");

}

Affichage_dessous(r);

Tam_Trm(s,rt,m);
}
