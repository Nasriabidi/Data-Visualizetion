#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "process.h"
#include "Affichage.h"

void SRTF (Info tab[],int m) {

printf("\n");
float ta=0;
	float tr=0;
 int r =0,u=0 ;
 char ch1[20];
 char ch2[100];
 char ch3[200];
Info aux ;
	Info tab2[50];
	Info tab3[50];
	ch3[0]=0;
 for(int h=0 ; h<m;h++){
tab2[h]=tab[h];
}

for(int h=0 ; h<m;h++){
tab3[h]=tab[h];
}
for(int o=0 ; o<m-1;o++){
for(int h = o+1 ; h <m ; h++){
	if(tab3[o].ta>tab3[h].ta){
	aux=tab3[h];
	tab3[h]=tab3[o];
	tab3[o]=aux;}
}
}

	for(int o=0 ; o<m-1;o++){
for(int h = o+1 ; h <m ; h++){
	if(tab2[o].te>tab2[h].te){
	aux=tab2[h];
	tab2[h]=tab2[o];
	tab2[o]=aux;}
}
}




strncpy(ch1, "", sizeof(ch1));
int h = 0; 
int p=0 ;
int time=0;

while(p!=m){
while(tab2[h].te !=0){

if(tab2[h].ta <=time){
ta+=time-tab2[h].ta;
time++;

tab2[h].ta=time;
int g=tab2[h].num;
tab2[h].te--;
if(tab2[h].te==0){
for(int w = 0 ; w <m ; w++){
	if(tab3[w].num==tab2[h].num){
	
	tr+=time-tab3[w].ta;
	
break; 
	
	}}}
ch1[r]=tab2[h].num;

u++;

	p=0;
	r++;
	
		for(int o=0 ; o<m;o++){

	if(((tab2[o].te<tab2[h].te)&&(tab2[o].te>0)&&(tab2[o].ta>=time))||(tab2[h].te==0)){
				

h=0;
	break;
	}
	else{
for(int o=0 ; o<m-1;o++){
for(int cn = o+1 ; cn <m ; cn++){
	if((tab2[o].te>tab2[cn].te)){
	aux=tab2[cn];
	tab2[cn]=tab2[o];
	tab2[o]=aux;}
		else if((tab2[o].te==tab2[cn].te)){
	if(tab2[o].ta>tab2[cn].ta){
	aux=tab2[cn];
	tab2[cn]=tab2[o];
	tab2[o]=aux;}}
}


for(int cn = 0 ; cn <m ; cn++){
	if((tab2[cn].num==g)){
	h=cn;
	break;
	}
}

}
	}
	}

}

else {
	
	int nb=0;
	for(int f = 0 ; f <m ; f++){
	if((tab2[f].ta<=time) && (tab2[f].te>0)){
	nb++;
}}
if(nb==0){
	for(int f = 0 ; f <m ; f++){
	if(tab3[f].ta>time){
		time++;
		ch1[r]=0;

r++;
u++;
h=0;
p=0;
break;
	}
	
}

}
else{

	h++;
if(h==m)
h=0;
}}

}
h++;
if(h==m)
h=0;

p++;

}
int s=0 ;
h=0;
 while(h<u){
 
	if(ch1[h]==ch1[h+1]){
			h++ ;
	}
else{

	ch2[s]=ch1[h];
	ch3[s+1]=h+1;
	s++;
	h++ ;}
	}
	
	Affichage_dessus("Shortest Remaining Time First",r);
	

 for(int h = 0 ; h <s ; h++){
 	if(ch2[h]==0)
 	printf("   X ");
 	else
	printf("   p %d",ch2[h]);
	printf("\t"); }
	
		printf("\n");
	printf("\n");
	printf("\t");
	 for(int h = 0 ; h<=s; h++){
	printf("%d ",ch3[h] );
	printf("\t");

}

Affichage_dessous(s);

Tam_Trm(ta,tr,m);




}
