#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "process.h"
#include "Affichage.h"

void multilevel(Info tab[], int m, int priority_quantum, int rr_quantum) {
    float s = 0;
    float rt = 0;
    int r = 0;

    Info aux;

    // Create an array to store completion times
    int completion_times[m];

    // Create a copy of the input array
    Info tab2[m];
    memcpy(tab2, tab, m * sizeof(Info));

    // Sort processes based on priority and arrival time
    for (int o = 0; o < m - 1; o++) {
        for (int h = o + 1; h < m; h++) {
            if (tab2[h].pr < tab2[o].pr || (tab2[h].pr == tab2[o].pr && tab2[h].ta < tab2[o].ta)) {
                aux = tab2[h];
                tab2[h] = tab2[o];
                tab2[o] = aux;
            }
        }
    }

    int time = 0;
    int current_priority = tab2[0].pr;

    // Display Gantt chart and additional information
    Affichage_dessus("Multilevel Priority with RR", m);

    for (int h = 0; h < m; h++) {
        printf("   P %d\t", tab2[h].num);
    }
    printf("\n");
    printf("\n");
    printf("\t");

    int cumulativeTime = 0;
    int quantum = 0;  // Initialize quantum

    for (int h = 0; h < m; h++) {
        if (tab2[h].pr != current_priority) {
            current_priority = tab2[h].pr;
            quantum = 0;  // Reset quantum when priority changes
        }

        completion_times[r] = cumulativeTime + ((tab2[h].te > priority_quantum) ? priority_quantum : tab2[h].te);
        cumulativeTime += priority_quantum;
        quantum += priority_quantum;
        rt += completion_times[r] - tab2[h].ta;

        if (tab2[h].te <= quantum) {
            s += completion_times[r] - tab2[h].ta - tab2[h].te;
        } else {
            aux = tab2[h];
            for (int i = h; i < m - 1; i++) {
                tab2[i] = tab2[i + 1];
            }
            tab2[m - 1] = aux;
            h--;
        }
        r++;
    }

    // Print debugging information
    printf("\nDebugging Info:\n");
    for (int i = 0; i < m; i++) {
        printf("Completion Time for P %d: %d\n", tab2[i].num, completion_times[i]);
    }

    // Display Gantt chart and additional information
    Affichage_dessous(r);

    Tam_Trm(s, rt, m);
}



