#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "process.h"
#include "Affichage.h"

void FIFO (Info tab[],int m) {
	float s=0;
	float rt=0;
	char ch1[20];
	char ch2[20];
	Info aux ;
int r =0 ;


printf("\n");

Info tab2[m];
 for(int h=0 ; h<m;h++){
tab2[h]=tab[h];
}
 

for(int o=0 ; o<m-1;o++){
for(int h = o+1 ; h <m ; h++){
	if(tab2[h].ta<tab2[o].ta){
	
	aux=tab2[h];
	tab2[h]=tab2[o];
	tab2[o]=aux;}
}
}


int time=0;
ch2[0]=0;
strncpy(ch1, "", sizeof(ch1));
for(int h = 0 ; h<m; h++){
	if(tab2[h].ta>time){
	
 ch1[r]=0;
 time=tab[h].ta;
 ch2[r+1]=time;
 
	
	r++;}
	s+=time-tab2[h].ta;

 ch1[r]=tab2[h].num;
 ch2[r+1]=time+tab2[h].te;
 time+=tab2[h].te;
	rt+=time-tab2[h].ta;
	r++;
	}

Affichage_dessus("First In First Out",r);

 for(int h = 0 ; h<r; h++){
 
	if(ch1[h]==0)
 	printf("    X ");
 	else
	printf("   P %d",ch1[h]);
	printf("\t");
	}
	printf("\n");
	printf("\n");
	printf("\t");
	
	 for(int h = 0 ; h<=r; h++){
	printf("%d    ",ch2[h] );
	
	
printf("\t");
}


Affichage_dessous(r);

Tam_Trm(s,rt,m);

}
