// gui.c
#include <gtk/gtk.h>
#include "headers.h"

GtkWidget *window;
GtkWidget *runButton;

void on_run_button_clicked(GtkButton *button, gpointer user_data) {
    // Call the appropriate scheduling function based on user choice
    int algorithm = GPOINTER_TO_INT(user_data);
    switch (algorithm) {
        case 1:
            FIFO((Info *)user_data, m);
            break;
        case 2:
            SJF((Info *)user_data, m);
            // Add more cases for other algorithms if needed
            break;
    }
}

void create_gui(int argc, char *argv[], Info tab[]) {
    gtk_init(&argc, &argv);

    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    GtkWidget *mainBox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
    gtk_container_add(GTK_CONTAINER(window), mainBox);

    for (int i = 0; i < m; i++) {
        runButton = gtk_button_new_with_label(g_strdup_printf("Run Algorithm for Process %d", tab[i].num));
        g_signal_connect(runButton, "clicked", G_CALLBACK(on_run_button_clicked), GINT_TO_POINTER(tab[i].num));
        gtk_box_pack_start(GTK_BOX(mainBox), runButton, TRUE, TRUE, 0);
    }

    gtk_widget_show_all(window);

    gtk_main();
}

