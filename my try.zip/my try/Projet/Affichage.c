#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void Affichage_dessus(char x[20],int r){
printf("\t");

for(int h = 0 ; h<strlen(x); h++){
 
printf("%c",x[h]);


	}
printf(":");
	

	printf("\n");
	printf("\t");
	for(int h = 0 ; h<strlen(x); h++){
 
printf("_");


	}
	
	printf("\n");
	printf("\n");
printf("\t");}

void Affichage_dessous(int r){
printf("\n");
printf("\n");

printf("\t");
	 for(int h = 0 ; h<r; h++){
if (h==r-1)
printf("|--------|");
else
printf("|-------");

	}

printf("\n");
printf("\n");
}


void Tam_Trm(float s,float rt,int m){
	printf("\t");
printf("---------------------------------");

printf("\n");
printf("\t");
printf("| Temps d'attente moyen   :%.2f\n",s/m);

printf("\n");
printf("\t");
printf("| Temps de rotation moyen :%.2f",rt/m);

printf("\n");
printf("\t");
printf("---------------------------------");
printf("\n");

printf("\n");
}

