typedef struct Info{
		   	int num ;
            int ta ;
 	 	    int te ;
 	 		float pr ;
 	 		
	  
}Info;


