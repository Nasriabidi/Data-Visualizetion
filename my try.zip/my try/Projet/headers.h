#include "process.h"

void FIFO (Info tab[],int m);
void PRI (Info tab[],int m);
void PRIP (Info tab[],int m,int qu);
void RR (Info tab[],int m,int z);
void SJF (Info tab[],int m); 
void SRTF (Info tab[],int m);
void multilevel(Info tab[], int m, int priority_quantum, int rr_quantum);

