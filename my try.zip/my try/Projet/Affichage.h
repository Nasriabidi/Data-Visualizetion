void Affichage_dessus(char x[],int r);
void Affichage_dessous(int r);
void Tam_Trm(float s,float rt,int m);

