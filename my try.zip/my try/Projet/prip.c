#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "process.h"
#include "Affichage.h"

  void PRIP (Info tab[],int m,int qu) {
 	

printf("\n");
float ta=0;
	float tr=0;
 int r =0,u=0,pr,x,y ;
 int v=0;
int n=0;
int k=0;
 char ch1[50];
 char ch2[100];
 char ch3[100];
Info aux ;
	Info tab2[50];
	Info tab3[50];
	
 for(int h=0 ; h<m;h++){
tab2[h]=tab[h];
}
for(int o=0 ; o<m-1;o++){
for(int h = o+1 ; h <m ; h++){
	if(tab2[o].pr<tab2[h].pr){
	aux=tab2[h];
	tab2[h]=tab2[o];
	tab2[o]=aux;}
}
}

for(int h=0 ; h<m;h++){
tab3[h]=tab[h];
}
for(int o=0 ; o<m-1;o++){
for(int h = o+1 ; h <m ; h++){
	if(tab3[o].ta>tab3[h].ta){
	aux=tab3[h];
	tab3[h]=tab3[o];
	tab3[o]=aux;}
}
}
strncpy(ch1, "", sizeof(ch1));
int h = 0; 
int p=0 ;
int nb1 =0;
int time=0;
ch3[0]=0;

while(p!=m){
while(tab2[h].te !=0){

if(tab2[h].ta <=time){
	ta+=time-tab2[h].ta;
time++;
tab2[h].te--;
if(tab2[h].te==0){
for(int w = 0 ; w <m ; w++){
	if(tab3[w].num==tab2[h].num){
	
	tr+=time-tab3[w].ta;
	
break; 
	
	}}}
tab2[h].ta=time;
 ch1[r]=tab2[h].num;
x=tab2[h].num;
 y=tab2[h].pr;
/*
tab2[h].pr--;
	
	 
	
	for(int o=0 ; o<m-1;o++){
for(int c = o+1 ; c <m ; c++){
	if(tab2[o].pr<tab2[c].pr){
	aux=tab2[c];
	tab2[c]=tab2[o];
	tab2[o]=aux;}
}
}*/
n=h;/*
for(int c = 0 ; c <m ; c++){
	if(tab2[c].num==x){
	tab2[c].pr++;
	n=c;}
	//break;
	  }*/
nb1=0;
v=0;

 k=0;
for(int c = 0 ; c <m ; c++){
	if((tab2[c].pr==y)&&(tab2[c].te>0) ){
	v++;
}
}
	if(v>1){
		int g=0;
		
		while(tab2[k].pr>=y){
			if((tab2[k].ta <=time) && (tab2[k].pr>y)&&(tab2[k].te >0))
			g++;
			if((tab2[k].ta <=time) && (tab2[k].pr==y))
			nb1++;
			k++;
			}
			if((nb1>1) && (tab2[n].te >0)&& (g==0) ){
			
				y=qu-1;
			
				if(tab2[n].te >=y){
				
				for(int j=0 ; j<y;j++){
					r++;
					ch1[r]=tab2[n].num;
					time++;
					tab2[n].te--;
					tab2[h].ta=time;
					u++;
					}}
				else{
				
		for(int j=0 ; j<tab2[n].te;j++){
					r++;u++;
					tab2[n].te--;
					ch1[r]=tab2[n].num;
					time++;
					}
			}
			}	
	}
	
u++;

	p=0;
	r++;
h=0;
tab2[n].ta++ ;
for(int o=0 ; o<m-1;o++){
for(int cn = o+1 ; cn <m ; cn++){
	 if((tab2[o].pr==tab2[cn].pr)){
	if(tab2[o].ta>tab2[cn].ta){
	aux=tab2[cn];
	tab2[cn]=tab2[o];
	tab2[o]=aux;}}
}}

for(int c = 0 ; c <m ; c++){
	if(tab2[c].num==x){
	tab2[c].ta--;
}
}
}
else {
	int nb=0;
	for(int f = 0 ; f <m ; f++){
	if((tab2[f].ta<=time) && (tab2[f].te>0)){
	nb++;
}}
if(nb==0){
	for(int f = 0 ; f <m ; f++){
	if(tab3[f].ta>time){
			while(tab3[f].ta>time){
		time++;
		ch1[r]=0;

r++;
u++;}
h=0;
p=0;
break;
	}
	
}

}
	
else{

	h++;
if(h==m)
h=0;}
}

}
h++;
if(h==m)
h=0;

p++;

}
int s=0 ;
h=0;
 while(h<u){
 
	if(ch1[h]==ch1[h+1]){
			h++ ;
	}
else{

	ch2[s]=ch1[h];
	ch3[s+1]=h+1;
	s++;
	h++ ;}
	}
	
	
 Affichage_dessus("Preemptive Priority ",r);
 for(int h = 0 ; h <s ; h++){
 	if(ch2[h]==0)
 	printf("    X ");
 	else
	printf("   p %d",ch2[h]);
	printf("\t"); }
	
		printf("\n");
	printf("\n");
	printf("\t");
	 for(int h = 0 ; h<=s; h++){
	printf("%d ",ch3[h] );
	printf("\t");

}
	 Affichage_dessous(s);

	 Tam_Trm(ta,tr,m);

}


