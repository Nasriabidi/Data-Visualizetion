 #include<stdio.h>
#include<stdlib.h> 
#include<string.h>
#include"headers.h"



	
		  FILE *fp ;
		 // FILE *fp1 ;
		   char x[500];
		   char ch[500];
		  int y=3;
		  int l ;
		  int f; 
		   int m = 0;
		  int i=0,j=0,nb=0;
int read_file(char proc[50]){

 
FILE *fp;

fp = fopen(proc,"r");

	while (fgets(x,sizeof(x),fp)){
		i=0;
		l=strlen(x);
			while(i<l){
			
				if(i==0)
					m++;
				
				break ;
			}
		}
	
	return	m/4;

}
	

int main (int argc, char *argv[]) {
	
  		  		  	 
int v=0;
FILE *fp;

if (argc < 2){
	printf("donnez le nom de fichier texte");
	printf("\n");
	return 0;
}

m = read_file(argv[1]);
if (m==0){
	printf("Votre fichier texte est vide");
	printf("\n");
	return 0;
}
Info tab[m];

fp = fopen(argv[1],"r");


while (fgets(x,sizeof(x),fp)){
		l=strlen(x);
		  	  		
if(nb==4){
	v++;
nb=0;
 }

if(nb!=0){
	i=0;
	strncpy(ch, "", sizeof(ch));
	while((i+3)<l){
	ch[i]=x[i+3];
	i++;
	}
	if(nb==1)
	
tab[v].ta=atoi(ch)  ;
else if(nb==2)
tab[v].te=atoi(ch) ;
else if(nb==3){ 
	j++;
tab[v].pr=atoi(ch)  ;
tab[v].num=v+1  ;

}
}
nb++;

}
	
	int u=0;
	Info tab2[m];
	for(int h=0 ; h<j;h++){
tab2[h]=tab[h];
 
}




printf("\n");
int i =0;
printf("\n");
printf("\t");
					for(int h = 0 ; h<m+1; h++){
printf("-----------------------");
}
		printf("\n");
for(int h = 0 ; h<m+1; h++){

		if(h!=0){
		
		
	printf("  Processus %d ",tab2[h-1].num);
	printf("\t");
		printf("   |");}
	else{
	printf("\t");
	printf("| Processus ");
	printf("\t");
			printf("    |");
	}
	
	printf("\t");
	
	
}
	printf("\n");
	printf("\t");
					for(int h = 0 ; h<m+1; h++){
printf("-----------------------");
}
		printf("\n");
for(int h = 0 ; h<m+1; h++){
if(h!=0){

	printf("%d",(int)tab2[h-1].ta);
	printf("\t");
		printf("   |");
	
	}
	else{
	printf("\t");
	printf("| temp d arrive");
	printf("\t");
		printf("    |");
	}
	printf("\t");
	printf("\t");
}
	printf("\n");
	printf("\t");
					for(int h = 0 ; h<m+1; h++){
printf("-----------------------");
}
		printf("\n");
	
	
	for(int h = 0 ; h<m+1; h++){
	if(h!=0)	{
	
	printf("%d",tab2[h-1].te);
	printf("\t");
		printf("   |");
	;}
else{
	printf("\t");
	printf("| temp d execution");

			printf("  |");
	}
printf("\t");
	printf("\t");
	


	}	
		printf("\n");
		printf("\t");
					for(int h = 0 ; h<m+1; h++){
printf("-----------------------");
}
		printf("\n");
for(int h = 0 ; h<m+1; h++){
	if(h!=0){
	
	printf("%d",(int)tab2[h-1].pr);
	printf("\t");
		printf("   |");
	;}
else{
	printf("\t");
	printf("| Priorite");
	printf("\t");
		printf("    |");
	}
	printf("\t");
	printf("\t");
	
	u++;
}
	printf("\n");
	printf("\t");
					for(int h = 0 ; h<m+1; h++){
printf("-----------------------");
}
		printf("\n");


int k;
		printf("\n");

printf("\n");
//if output  == console else 
do{
		printf("\n");
		printf("\t");
printf("Si vous voulez FIFO tapez 1");
	printf("\n");
	printf("\n");
	printf("\t");
	printf("Si vous voulez SJF tapez 2 ");
	printf("\n");
	printf("\n");
	printf("\t");
	printf("Si vous voulez ROUND ROBIN tapez 3 ");
	printf("\n");
	printf("\n");
	printf("\t");
	printf("Si vous voulez SRTF tapez 4 ");
	printf("\n");
	printf("\n");
	printf("\t");
	printf("Si vous voulez PRIORITE NON PREEMPTIVE tapez 5 ");
	printf("\n");
	printf("\n");
	printf("\t");
	printf("Si vous voulez PRIORITE PREEMPTIVE tapez 6 ");
	printf("\n");
	printf("\n");
	printf("\t");
	printf("Si vous voulez multi tapez 7 ");
	printf("\n");
	printf("\n");
	printf("\t");
	printf("Si vous voulez quitter tapez 0 ");
	printf("\n");
	printf("\n");
	printf("\t");
	scanf("%d",&f);
	printf("\n");
	if(f==1)
	FIFO (tab2,m); 
else 	if(f==2)
	SJF(tab2,m);
	

else 	if(f==3){
do{
printf("\t");
printf("Donnez le quantum");
	printf("\n");
	printf("\t");
	scanf("%d",&k);
	printf("\n");}
	
	while(k==0);
	RR(tab2,m,k);
}
	else 	if(f==4)
	SRTF(tab2,m);
	
		else 	if(f==5)
	PRI(tab2,m);

else 	if(f==6){
do{
printf("\t");
printf("Donnez le quantum");
	printf("\n");
	printf("\t");
	scanf("%d",&k);
	printf("\n");}
	
	while(k==0);
	PRIP(tab2,m,k);
} else if (f == 7) {
        // Multilevel Priority with Round Robin
        do {
            printf("\t");
            printf("Donnez le quantum pour la priorite");
            printf("\n");
            printf("\t");
            scanf("%d", &k);
            printf("\n");
        } while (k == 0);
        // Add a constant Round Robin quantum, for example, 2
        int rr_quantum = 2;
        multilevel(tab2, m, k, rr_quantum);
    }
} while (f != 0);
    return 0;
}
